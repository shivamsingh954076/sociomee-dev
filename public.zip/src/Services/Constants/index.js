// Category List when user will create new group
export const GET_ALL_GROUP_CATEGORY = "GET_ALL_GROUP_CATEGORY";

// Use to create new group
export const GET_ALL_CREATE_GROUP = "GET_ALL_CREATE_GROUP";


// get all biz category
export const GET_BIZ_CATEGORY = "GET_BIZ_CATEGORY";

// get biz sub category
export const GET_BIZ_SUBCATEGORY = "GET_BIZ_SUBCATEGORY";






// 
// Groups
export const CREATE_GROUP = "CREATE_GROUP";
export const DELETE_GROUP = "DELETE_GROUP";
export const GET_ALL_GROUPS_BY_USER_ID = "GET_ALL_GROUPS_BY_USER_ID";
export const GET_ALL_USER_GROUPS = "GET_ALL_USER_GROUPS";
export const GET_SINGLE_GROUP = "GET_SINGLE_GROUP";
export const GET_GROUP_ADMINISTRATER = "GET_GROUP_ADMINISTRATER";