import React from 'react';
import ReactDOM from 'react-dom';
import './App.css';
import Root from './Root';

function App() {
  return (
      <Root>
      </Root>
  );
}

export default App;
